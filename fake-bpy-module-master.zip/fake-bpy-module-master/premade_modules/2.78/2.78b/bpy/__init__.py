from . import types
from . import ops
from . import path
from . import props
from . import app
from . import utils

data = None  # type:  bpy.types.BlendData
'''Access to Blenders internal data '''
