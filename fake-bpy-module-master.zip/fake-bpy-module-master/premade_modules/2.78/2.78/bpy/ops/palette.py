def color_add():
    '''Add new color to active palette 

    '''

    pass


def color_delete():
    '''Remove active color from palette 

    '''

    pass


def new():
    '''Add new palette 

    '''

    pass
