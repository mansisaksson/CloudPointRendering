def add():
    '''Add new cache 

    '''

    pass


def bake(bake=False):
    '''Bake physics 

    :param bake: Bake 
    :type bake: boolean, (optional)
    '''

    pass


def bake_all(bake=True):
    '''Bake all physics 

    :param bake: Bake 
    :type bake: boolean, (optional)
    '''

    pass


def bake_from_cache():
    '''Bake from cache 

    '''

    pass


def free_bake():
    '''Free physics bake 

    '''

    pass


def free_bake_all():
    '''Free all baked caches of all objects in the current scene 

    '''

    pass


def remove():
    '''Delete current cache 

    '''

    pass
