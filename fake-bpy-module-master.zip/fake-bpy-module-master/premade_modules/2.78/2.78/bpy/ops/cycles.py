def use_shading_nodes():
    '''Enable nodes on a material, world or lamp 

    '''

    pass
