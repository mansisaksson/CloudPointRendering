def svg(filepath="", filter_glob="*.svg"):
    '''Load a SVG file 

    :param filepath: File Path, Filepath used for importing the file 
    :type filepath: string, (optional, never None)
    :param filter_glob: filter_glob 
    :type filter_glob: string, (optional, never None)
    '''

    pass
