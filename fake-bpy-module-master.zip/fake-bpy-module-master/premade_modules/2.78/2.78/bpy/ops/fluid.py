def bake():
    '''Bake fluid simulation 

    '''

    pass


def preset_add(name="", remove_active=False):
    '''Add or remove a Fluid Preset 

    :param name: Name, Name of the preset, used to make the path name 
    :type name: string, (optional, never None)
    :param remove_active: remove_active 
    :type remove_active: boolean, (optional)
    '''

    pass
