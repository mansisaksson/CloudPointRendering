def autoexec_warn_clear():
    '''Ignore autoexec warning 

    '''

    pass


def execute_preset(filepath="", menu_idname=""):
    '''Execute a preset 

    :param filepath: filepath 
    :type filepath: string, (optional, never None)
    :param menu_idname: Menu ID Name, ID name of the menu this was called from 
    :type menu_idname: string, (optional, never None)
    '''

    pass


def python_file_run(filepath=""):
    '''Run Python file 

    :param filepath: Path 
    :type filepath: string, (optional, never None)
    '''

    pass


def reload():
    '''Reload Scripts 

    '''

    pass
