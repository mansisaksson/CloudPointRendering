def end_frame_set():
    '''Set the end frame 

    '''

    pass


def start_frame_set():
    '''Set the start frame 

    '''

    pass


def view_all():
    '''Show the entire playable frame range 

    '''

    pass


def view_frame():
    '''Reset viewable area to show range around current frame 

    '''

    pass
