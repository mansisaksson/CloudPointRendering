def new():
    '''Add a new world 

    '''

    pass
