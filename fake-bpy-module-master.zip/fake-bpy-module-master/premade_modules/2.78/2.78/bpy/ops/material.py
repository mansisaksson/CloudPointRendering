def copy():
    '''Copy the material settings and nodes 

    '''

    pass


def new():
    '''Add a new material 

    '''

    pass


def paste():
    '''Paste the material settings and nodes 

    '''

    pass


def sss_preset_add(name="", remove_active=False):
    '''Add or remove a Subsurface Scattering Preset 

    :param name: Name, Name of the preset, used to make the path name 
    :type name: string, (optional, never None)
    :param remove_active: remove_active 
    :type remove_active: boolean, (optional)
    '''

    pass
