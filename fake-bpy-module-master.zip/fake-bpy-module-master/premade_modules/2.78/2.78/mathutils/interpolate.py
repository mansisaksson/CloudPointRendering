def poly_3d_calc(veclist, pt):
    '''Calculate barycentric weights for a point on a polygon. 

    :param veclist: list of vectors 
    :type veclist: 
    :param pt: point :rtype: list of per-vector weights 
    :type pt: 
    '''

    pass
