def keyconfig_export(wm, kc, filepath):
    '''

    '''

    pass


def keyconfig_merge(kc1, kc2):
    '''note: kc1 takes priority over kc2 

    '''

    pass


def keyconfig_test(kc):
    '''

    '''

    pass


def km_exists_in(km, export_keymaps):
    '''

    '''

    pass
