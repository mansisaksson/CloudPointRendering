# Bug Report / Feature Request / Disscussions

If you want to report problem or request feature, please make issues.

https://github.com/nutti/fake-bpy-module/issues

You can discuss fake-bpy-module at other places.
See the link below for further details.

* [Blender Artists](https://blenderartists.org/t/fake-bpy-modules-for-code-auto-completion-on-ide/697936)
