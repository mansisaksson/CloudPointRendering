---
name: Feature Request
about: Use this template for feature request.
title: ''
labels: Enhancement
assignees: ''

---

**Description about the feature**  
*The description about the feature. It is good to clear who will benefit with this feature.*


**Are you willing to contribute about this feature. (Yes/No)**  


**Screenshots** [Optional]  
*It is good to understand the features if you attach the screenshotsfile.*


**Additional comments** [Optional]
